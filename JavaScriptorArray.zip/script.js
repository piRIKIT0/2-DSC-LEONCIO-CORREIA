//variaveis unitarias
const nome1 = 'joão';
const nome2 = 'maria';
const nome3 = 'jefferson';

//variaveis de array
const nomes1 = ['joão', 'maria', 'jefferson'];
const nomes2 = ['geraldo', 'luciana', 'julio'];
//imprimndo valores de array
nomes1[10] = 'Ramon Dino'
console.log(nomes1[10]);//criando dinamicamente



